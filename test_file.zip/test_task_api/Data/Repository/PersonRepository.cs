﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using test_task_api.Interfaces;
using test_task_api.Models;

namespace test_task_api.Data.Repository
{
    public class PersonRepository : IPersonRepository
    {

        private readonly ApplicationDbContext _db;
        public PersonRepository(ApplicationDbContext db)
        {
            _db = db;
        }

        public async Task<Person> CreatePersonAsync(Person person)
        {
            _db.Persons.Add(person);
            await _db.SaveChangesAsync();
            return person;
        }

        public async Task<Person> DeletePersonAsync(string id)
        {
            var person = _db.Persons.FirstOrDefault(i => i.Id == id);
            _db.Persons.Remove(person);
            await _db.SaveChangesAsync();
            return person;
        }

        public async Task<List<Person>> GetPersonAsync()
        {
            return await _db.Persons.ToListAsync();
        }

        public async Task<Person> GetPersonIdAsync(string id)
        {
            return await _db.Persons.FirstOrDefaultAsync(i => i.Id == id);
        }

        public async Task<Person> UpdatePersonAsync(Person person)
        {
            _db.Update(person);
           await _db.SaveChangesAsync();
            return person;
        }
    }
}
