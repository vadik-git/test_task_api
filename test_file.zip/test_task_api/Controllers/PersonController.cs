﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using test_task_api.Data;
using test_task_api.Interfaces;
using test_task_api.Models;

namespace test_task_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PersonController : ControllerBase
    {
        private readonly IPersonRepository _person;

        public PersonController(IPersonRepository person)
        {
            _person = person;

        }

        [HttpGet]
        
        public async Task<IActionResult> GetPerson()
        {
            return Ok( await _person.GetPersonAsync());
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetPersonId(string id)
        {
            return Ok(await _person.GetPersonIdAsync(id));
        }

        [HttpPost]
        public async Task<IActionResult> CreatePerson(Person person)
        {
            return Ok(await _person.CreatePersonAsync(person));
        }

        [HttpPut]
        public async Task<IActionResult>UpdatePerson(Person person)
        {
            return Ok(await _person.UpdatePersonAsync(person));
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult>DeletePerson(string id)
        {
            return Ok(await _person.DeletePersonAsync(id));
        }
    }
}
