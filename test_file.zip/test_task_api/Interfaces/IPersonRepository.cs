﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using test_task_api.Models;

namespace test_task_api.Interfaces
{
    public  interface IPersonRepository
    {
        Task<List<Person>> GetPersonAsync();

        Task<Person> GetPersonIdAsync(string id);

        Task<Person> CreatePersonAsync(Person person);

        Task<Person> UpdatePersonAsync(Person person);

        Task<Person> DeletePersonAsync(string id);
    }
}
