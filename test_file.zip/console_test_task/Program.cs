﻿using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using test_task_api;
using test_task_api.Models;

namespace console_test_task
{
    class Program
    {
        HttpClient client = new HttpClient();
        static async Task Main(string[] args)
        {
            Program program = new Program();
            await program.GetPersonJson();
            await program.CreatePerson();

        }

        public async Task GetPersonJson()
        {
            Console.WriteLine("Get person");
            string persons = await client.GetStringAsync("http://localhost:45100/api/person");
                Console.WriteLine(persons);
        }

        public async Task CreatePerson()
        {
            Console.WriteLine("Create person");
            var person = new Person() { 
            
                FirstName="Anatoliy",
                LastName="Shevchenko"

            };

            var json = JsonConvert.SerializeObject(person);
            var data = new StringContent(json, Encoding.UTF8, "application/json");

            var url = "http://localhost:45100/api/person";
            var response = await client.PostAsync(url, data);

            string result = response.Content.ReadAsStringAsync().Result;
            Console.WriteLine(result);
        }

    }
}
